 _    _      _                            _           ___        _       ______ _____ 
| |  | |    | |                          | |         / _ \      | |      |  ___|  ___|
| |  | | ___| | ___ ___  _ __ ___   ___  | |_ ___   / /_\ \_   _| |_ ___ | |_  |___ \ 
| |/\| |/ _ \ |/ __/ _ \| '_ ` _ \ / _ \ | __/ _ \  |  _  | | | | __/ _ \|  _|     \ \
\  /\  /  __/ | (_| (_) | | | | | |  __/ | || (_) | | | | | |_| | || (_) | |   /\__/ /
 \/  \/ \___|_|\___\___/|_| |_| |_|\___|  \__\___/  \_| |_/\__,_|\__\___/\_|   \____/ 
                    ___   ___            ______     _ _       _                       
                   / / | / (_)           |  ___|   | | |     | |                      
 ______   _   _   / /| |/ / _ _ __   __ _| |_ _   _| | | __ _| |__                    
|______| | | | | / / |    \| | '_ \ / _` |  _| | | | | |/ _` | '_ \                   
         | |_| |/ /  | |\  \ | | | | (_| | | | |_| | | | (_| | | | |                  
          \__,_/_/   \_| \_/_|_| |_|\__, \_|  \__,_|_|_|\__,_|_| |_|                  
                                     __/ |                                

AutoF5 is a simple tool written in PowerShell. The purpose is to allow user to search for their desired subreddit and have the page refresh at a set interval.

If you'd like to change the interval in which the subreddit is refreshed, right-click and edit the .ps1 file and adjust the value following 'sleep -Seconds'.

Any issues or suggestions, please raise this via Github and I can look to resolve/implement them ASAP.