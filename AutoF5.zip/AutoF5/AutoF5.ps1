﻿Echo "Auto F5"
Echo "u/KingFullah"

$subreddit = Read-Host 'Which subreddit are you looking for?'

#Launch Site
start-process -FilePath 'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe' -ArgumentList "www.reddit.com/r/$($subreddit)"

#Refresh Browser
while(1) { 
    sleep -Seconds 60
    $wshell = New-Object -ComObject wscript.shell 
    if($wshell.AppActivate('Chrome')) {
    Sleep 1 
    $wshell.SendKeys('{F5}')  
    } else { break; }
}

